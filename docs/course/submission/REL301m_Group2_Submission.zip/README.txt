REL301m - Group 2
Hard, Uncertain, or Learnable? A Controlled Study of Preference Allocation in Preference-Conditioned MORL

REL301m_Report.pdf: English report, 26 pages; text preserved during image optimization.
REL301m_Slides.pdf: 12 English slides, fixed 16:9 layout.
REL301m_Demo.mp4: narrated real-application demonstration, 720p H.264/AAC.
The original 1080p narrated recording is available from the repository README.

Source code and editable report/slide sources: https://github.com/Am2uocVi3t/REL301m_AdaptivePreferenceMORL/tree/codex/course-submission-20261112

The original final-test gate remains locked. Adaptive-allocation superiority is unestablished.
